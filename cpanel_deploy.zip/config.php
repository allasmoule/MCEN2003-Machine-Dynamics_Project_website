<?php
/**
 * Local XAMPP defaults for testing. Replace DB_* with your real cPanel
 * MySQL credentials before deploying, and change ADMIN_PASSWORD_HASH.
 * This file is gitignored — never commit real credentials.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'mcen2003_site');
define('DB_USER', 'root');
define('DB_PASS', '');

// Fixed admin sign-in — logging into the regular student login form with this
// exact email + password goes to the admin panel instead of the tutorial.
// Regenerate the hash with: php -r "echo password_hash('new-password', PASSWORD_DEFAULT), PHP_EOL;"
define('ADMIN_EMAIL', 'Raju.ahamedruet07@gmail.com');
define('ADMIN_PASSWORD_HASH', '$2y$10$eEYOvvBXud5ind9QyRYcBORUdVUxTMcqPQ9wkHLFTwu/osfOxjqOS');

define('APP_SECRET', '16f8aaa4fc2ecf0043378d6cdcca083c64b17ff1c5264c1356b38b5b05e90476');
